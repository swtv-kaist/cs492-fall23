int main() {
		char *ptr, c1='a', c2='b';
		assert(ptr!= &c1);
		assert(ptr!= &c2);
}
